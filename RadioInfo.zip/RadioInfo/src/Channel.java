public class Channel {
    public final String id;
    public final String name;
    public final int pageNr;

    public Channel(String id, String name, int pageNr) {
        this.id = id;
        this.name = name;
        this.pageNr = pageNr;
    }
}
